﻿/*
 * PLUGIN EDIT
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.EditTrackers			= "Editar Torrent...";
 theUILang.EditTorrentProperties	= "Propiedades del Torrent";
 theUILang.errorAddTorrent		= "Error al agregar el torrent";
 theUILang.errorWriteTorrent		= "Error al escribir el torrent";
 theUILang.errorReadTorrent		= "Error al leer el torrent";
 theUILang.cantFindTorrent		= "El torrent original no fué encontrado."

thePlugins.get("edit").langLoaded();