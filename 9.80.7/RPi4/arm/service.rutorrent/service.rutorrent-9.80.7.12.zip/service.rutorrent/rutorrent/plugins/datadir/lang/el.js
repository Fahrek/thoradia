﻿/*
 * PLUGIN DATADIR
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.DataDir		= "Αποθήκευση στο";
 theUILang.DataDirMove		= "Μετακίνηση αρχείων δεδομένων";
 theUILang.datadirDlgCaption	= "Φάκελος δεδομένων torrent";
 theUILang.datadirDirNotFound	= "Πρόσθετο DataDir: Μη έγκυρος φάκελος";
 theUILang.datadirSetDirFail	= "Πρόσθετο DataDir: Η λειτουργία απέτυχε";

thePlugins.get("datadir").langLoaded();