﻿/*
 * PLUGIN DATA
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.getData		= "Obtener archivo";
 theUILang.cantAccessData	= "El Webserver no puede acceder a los datos de este torrent.";

thePlugins.get("data").langLoaded();