﻿/*
 * PLUGIN DISKSPACE
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.diskNotification	= "Advarsel! Disken er full. rTorrent kommer kanskje ikke til å kjøre riktig, og ingen data lastes ned til du frigjør litt diskplass.";

thePlugins.get("diskspace").langLoaded();