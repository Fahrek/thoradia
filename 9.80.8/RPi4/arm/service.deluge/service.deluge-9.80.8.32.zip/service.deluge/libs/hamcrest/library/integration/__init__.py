"""Utilities for integrating Hamcrest with other libraries."""

from .match_equality import match_equality

__author__ = "Jon Reid"
__copyright__ = "Copyright 2011 hamcrest.org"
__license__ = "BSD, see License.txt"
