﻿/*
 * PLUGIN EXTRATIO
 *
 * Italian language file.
 *
 * Author: Gianni
 */

 theUILang.ratioRulesManager	= "Regolatore";
 theUILang.mnu_ratiorule	= "Regole del Ratio";
 theUILang.ratAddRule		= "Aggiungi";
 theUILang.ratDelRule		= "Cancella";
 theUILang.ratUpRule		= "Su";
 theUILang.ratDownRule		= "Giù";
 theUILang.ratioIfLegend	= "Se";
 theUILang.ratLabelContain	= "L'etichetta del torrent contiene";
 theUILang.ratTrackerContain	= "Uno degli indirizzi dei tracker contiene";
 theUILang.ratTrackerPublic	= "Tutti i tracker del torrent sono pubblici";
 theUILang.ratTrackerPrivate	= "Uno dei tracker del torrent è privato";
 theUILang.ratioThenLegend	= "Allora";
 theUILang.setRatioTo		= "Imposta ratio a";
 theUILang.setChannelTo		= "Imposta limite a";
 theUILang.ratioNewRule		= "Nuova regola";

thePlugins.get("extratio").langLoaded();
